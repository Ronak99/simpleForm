   
   //validation.js is the point where the complete validation of the form takes place
   //all the validation parameters are set to false initially
   
   var nameChecked=false; 
   
   var usernameChecked = false;
   
   var mailChecked = false;
   
   var passwordChecked = false;
   
   var mobileChecked = false;
   
   var stateChecked = false;
   
   var cityChecked = false;
   
   var imageChecked = false;
   
   function validate(id){ 

      //recieves the id of the element on which the validate function is working upon currently

    switch(id){
         
         case "name":{     //id for name field
               nameValidation(id);
               break;
         }
         
         case "username":{ //id for usermame field
              usernameValidation(id);
               break;
         }
         
         case "mail":{  //id for email field
               mailValidation(id);
               break;
            }
         case "password":{   //id for the password field
               passwordValidation(id);
               break;
            }
            
        case "mobile":{    //id for the contact field
               mobileValidation(id);
               break;
            }
            
      case "file":{     //id for the image or the file field
               fileValidation(id);
               break;
            }
            
     case "states":{  //id for the states drop down field
               stateValidation(id);
               break;
            }
            
     case "cities":{    //id for the cities drop down field
               cityValidation(id);
               break;
            }
      }
      
      //ensures that if all the validation parameters returns true, only then
      //the form becomes submittable
      
      if(nameChecked && usernameChecked && mailChecked && passwordChecked && stateChecked && mobileChecked && cityChecked &&        imageChecked){
         
         $("#submit").removeAttr("disabled");
         $("#submit").css("opacity",1);
         
      }else{
         $("#submit").attr("disabled","disabled");
         $("#submit").css("opacity",0.5);
         
      }
     
   }
   
   //name validation begins
   function nameValidation(id){
      
      //uses regex to ensure that only a specific type of 
      //input gets in, no special symbols or numbers are 
      //allowed by this function
      
       if($("#"+id).val()===""){
          //if no value is entered, return false
                  $("#"+id+" + .errorText").html("You can't leave the field empty ");
                  
                   $("#"+id).addClass("errorField");
                   
                   nameChecked = false;
      }
       else{
             if($("#"+id).val().match(/^[a-z\s]{2,}$/gi)){
                   
                      $("#"+id+" + .errorText").html("");
                     $("#"+id).removeClass("errorField");
                       nameChecked = true;
             }
             else{
                     $("#name + .errorText").html("No special symbol and numbers are allowed in name");
                   $("#"+id).addClass("errorField");
                   nameChecked = false;
             }
                  
      }
               
   }
   
   
   //username validation begins
    function usernameValidation(id){
      //uses regex to ensure that no special symbol gets in, 
      //only numbers are allowed
      
      
       if($("#"+id).val()===""){
          
                  $("#"+id+" + .errorText").html("You can't leave the field empty");
                  
                   $("#"+id).addClass("errorField");
                   
                   usernameChecked = false;
               }
               else{
                  if($("#"+id).val().match(/^[a-z0-9\s]{1,}$/gi)){
                   
                      $("#"+id+" + .errorText").html("");
                     $("#"+id).removeClass("errorField");
                      usernameChecked  = true;
                  }
                  else{
                     $("#"+id+" + .errorText").html("No special symbols are allowed in username");
                   $("#"+id).addClass("errorField");
                   usernameChecked = false;
                  }
                  
               }
   }
   
   
   //mail validation begins
   function mailValidation(id){
      //uses regex to ensure that similar string to
      // an email address is entered
      
      
       if($("#"+id).val()===""){
          
                  $("#"+id+" + .errorText").html("You can't leave the field empty");
                  
                   $("#"+id).addClass("errorField");
                   
                   mailChecked = false;
      }
        else{
            if($("#"+id).val().match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{3}$/gi)){
                   
                      $("#"+id+" + .errorText").html("");
                     $("#"+id).removeClass("errorField");
                      mailChecked  = true;
            }
            else{
                     $("#"+id+" + .errorText").html("Not a valid email");
                   $("#"+id).addClass("errorField");
                   mailChecked = false;
             }
                  
       }
   }
   
   
   //password validation begins
   function passwordValidation(id){
      //this function does not forces the user to
      // include some specific symbol for a strong password.
      //it simply ensures that the password is atleast 8 characters or longer
      
      
       if($("#"+id).val()===""){
          
                  $("#"+id+" + .errorText").html("You can't leave the field empty");
                  
                   $("#"+id).addClass("errorField");
                   
                   passwordChecked = false;
        }
         else{
                  if($("#"+id).val().length>7){
                   
                      $("#"+id+" + .errorText").html("");
                      
                     $("#"+id).removeClass("errorField");
                     
                      passwordChecked  = true;
                  }
                  
                  else{
                     $("#"+id+" + .errorText").html("Password should be longer than 7 characters");
                     
                   $("#"+id).addClass("errorField");
                   
                   passwordChecked = false;
                   
                  }
                  
       }
   }
   
   
   //contact validation begins
   function mobileValidation(id){
      //checks that the input does not contains a letter
      // and the limit does not exeeds 10 numbers
      
       if($("#"+id).val()===""){
          
                  $("#"+id+" + .errorText").html("You can't leave the field empty");
                  
                   $("#"+id).addClass("errorField");
                   
                   mobileChecked = false;
        }
        else{
           
                  if($("#"+id).val().match(/^[0-9.-]{10}$/gi)){
                   
                      $("#"+id+" + .errorText").html("");
                      
                     $("#"+id).removeClass("errorField");
                     
                      mobileChecked  = true;
                  }
                  
                  else{
                     
                   $("#"+id+" + .errorText").html("Not a valid phone number");
                   
                   $("#"+id).addClass("errorField");
                   
                   mobileChecked = false;
                  }
                  
     }
   }
   
   
   //fileValidation begins
    function fileValidation(id){
      
      //this function ensure that the file uploaded or selected is 
      //definitely an image type and not of some other type
      
       if($("#"+id).val()===""){
          
                  $("#"+id+" + .errorText").html("You can't leave the field empty");
                  
                   $("#"+id).addClass("errorField");
                   
                   imageChecked = false;
       }
       else{
                  
                  var imageName = $("#"+id).val();
                  var ext = imageName.split(".");
                  var actualExt = ext[ext.length-1];
                  
                  switch(actualExt){
                     
                     case "jpg":
                     case "png":
                     case "JPG":
                     case "PNG":   {
                           
                      $("#"+id+" + .errorText").html("");
                      
                     $("#"+id).removeClass("errorField");
                     
                      imageChecked  = true;
                      
                      break;
                   }
                   
                      default:{
                            
                          //if neither a png or jpg, show error 
                          
                       $("#"+id+" + .errorText").html("Please upload an image with extension png or jpg");
                       
                     $("#"+id).addClass("errorField");
                     
                      imageChecked  = false;
                      
                      break;
                   }    
               }
                  
       }
      
   }
   
   
   //state drop down validation begins
   function stateValidation(id){
      
      if($("#"+id).val()===""){
          
                  $("#"+id+" + .errorText").html("You can't leave the field empty");
                  
                   $("#"+id).addClass("errorField");
                   
                   stateChecked = false;
        }
        else   {
                   $("#"+id+" + .errorText").html("");
                  
                   $("#"+id).removeClass("errorField");
                   
                   $("#cities").change();
                   
                   stateChecked = true;
                      
        }
        
        /*setTimeout(function(){
           
           //this timeout function enables the main function to quickly
           // see if the city value remains null while the value of state
           //  is changed so as to prevent the submit button from getting enabled
           //   and preventing the user to submit a false value in the database
           
           
        if($("#cities").val()===""){
          
                  $("#cities + .errorText").html("Please select a city");
                  
                  cityChecked = false;
                
        }
          
      },1);  */
      
      
      
   }
   
   
   //city validation begins
   function cityValidation(id){
      
      //validates that a value in the city drop down is present
      
      if($("#"+id).val()===""){
          
                  $("#"+id+" + .errorText").html("You can't leave the field empty");
                  
                   $("#"+id).addClass("errorField");
                   
                   cityChecked = false;
                   
        }
        else{
           $("#"+id+" + .errorText").html("");
                  
                   $("#"+id).removeClass("errorField");
                   
                   cityChecked = true;
                   
        }
       

   }
  