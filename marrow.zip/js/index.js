$(function(){
   
   $("#states").on("change",callForCities);
  
  //index.js is responsible for the dynamic population of the cities
  // drop drown list on the basis of the state that is selected
  
   function callForCities(){
      
      var selectedState = $("#states").val(); //gets the selected value from the drop down list
      
      $.ajax({
         
         "type":"GET",
         
         "url":"fetchCities.php?stateId="+selectedState,
         
         success:function(data){
            $("#cities").html(data);
         }
         
      });
      
   }
   
 
   
});